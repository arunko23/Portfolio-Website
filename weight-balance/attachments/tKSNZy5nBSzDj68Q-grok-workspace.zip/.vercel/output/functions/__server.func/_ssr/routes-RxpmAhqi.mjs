import { i as __toESM } from "../_runtime.mjs";
import { R as require_react, l as require_react_dom, y as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-RxpmAhqi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var import_react_dom = require_react_dom();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var tones = {
	neutral: "bg-surface-2 text-muted border-border",
	good: "bg-good/15 text-good border-good/30",
	warn: "bg-warn/15 text-warn border-warn/30",
	bad: "bg-bad/15 text-bad border-bad/30"
};
function Badge({ className, tone = "neutral", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-sm border px-2 py-0.5 text-xs font-medium", tones[tone], className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap font-medium transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-bg disabled:pointer-events-none disabled:opacity-40", {
	variants: {
		variant: {
			primary: "bg-primary text-primary-foreground hover:bg-primary/90",
			secondary: "bg-surface-2 text-fg border border-border hover:bg-surface",
			ghost: "text-muted hover:text-fg hover:bg-surface-2",
			danger: "bg-bad/15 text-bad hover:bg-bad/25"
		},
		size: {
			sm: "h-9 rounded-sm px-3 text-sm",
			md: "h-11 rounded-md px-4 text-sm",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "secondary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(({ className, variant, size, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
var Input = (0, import_react.forwardRef)(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
	ref,
	className: cn("flex h-11 w-full rounded-md border border-border bg-surface px-3 text-sm text-fg tabular-nums", "placeholder:text-subtle", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", "disabled:opacity-40", className),
	...props,
	suppressHydrationWarning: true
}));
Input.displayName = "Input";
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("block text-xs font-medium uppercase tracking-[0.08em] text-muted", className),
		...props
	});
}
/**
* Pixel geometry digitized from AMM Figure 1/3 (the supplied page-9 chart).
*
* CG lines on this chart are NOT vertical: each labelled millimetre value has
* a printed tick on the top scale and a (usually different) tick on the bottom
* scale, and the printed grid line is the straight segment joining those ticks.
*
* Plotting a CG therefore:
*  1. looks up X on the top scale and X on the bottom scale (piecewise-linear
*     between neighbouring printed marks)
*  2. interpolates X at the plotted weight along that same segment
*
* Entering an exact labelled value (3350, 3400, 3500, 3550, …) therefore lands
* on the printed line. Values between two marks sit at the CG-proportional
* distance between those two printed lines.
*/
var CHART = {
	imageWidth: 1150,
	imageHeight: 910,
	plotLeft: 270,
	plotRight: 1138,
	plotTop: 267,
	plotBottom: 785,
	weightMin: 1e3,
	weightMax: 1600,
	cgMin: 3300,
	cgMax: 3650
};
/** Top-scale CG ticks: [mm, x px] at plotTop (1000 kg). */
var TOP_CG = [
	[3350, 382],
	[3400, 488],
	[3450, 593],
	[3500, 698],
	[3550, 802],
	[3600, 907],
	[3650, 1013]
];
/** Bottom-scale CG ticks: [mm, x px] at plotBottom (1600 kg). */
var BOTTOM_CG = [
	[3350, 313],
	[3400, 488],
	[3450, 662],
	[3500, 838],
	[3532, 950],
	[3550, 1013],
	[3565, 1066]
];
/**
* Weight grid: [kg, y px]. 25 kg minor lines digitized from the printed chart
* so a weight of 1200 kg sits on the printed 1200 line, not a linear average
* that drifts a pixel or two.
*/
var WEIGHT_Y = [
	[1e3, 267],
	[1025, 289],
	[1050, 310],
	[1075, 332],
	[1100, 354],
	[1125, 375],
	[1150, 397],
	[1175, 418],
	[1200, 439],
	[1225, 461],
	[1250, 482],
	[1275, 504],
	[1300, 525],
	[1325, 548],
	[1350, 569],
	[1375, 591],
	[1400, 611],
	[1425, 634],
	[1450, 655],
	[1475, 677],
	[1500, 697],
	[1525, 719],
	[1550, 741],
	[1575, 762],
	[1600, 785]
];
var LB_PER_KG = 2.2046226218;
var MM_PER_IN = 25.4;
function kgToLb(kg) {
	return kg * LB_PER_KG;
}
function lbToKg(lb) {
	return lb / LB_PER_KG;
}
function mmToIn(mm) {
	return mm / MM_PER_IN;
}
function inToMm(inches) {
	return inches * MM_PER_IN;
}
function interp(table, v) {
	if (table.length < 2) return table[0]?.[1] ?? 0;
	if (v <= table[0][0]) {
		const [a, b] = [table[0], table[1]];
		return a[1] + (v - a[0]) * (b[1] - a[1]) / (b[0] - a[0]);
	}
	for (let i = 0; i < table.length - 1; i++) if (v <= table[i + 1][0]) {
		const a = table[i];
		const b = table[i + 1];
		return a[1] + (v - a[0]) * (b[1] - a[1]) / (b[0] - a[0]);
	}
	const a = table[table.length - 2];
	const b = table[table.length - 1];
	return a[1] + (v - a[0]) * (b[1] - a[1]) / (b[0] - a[0]);
}
function invertInterp(table, px) {
	const swapped = table.map(([v, p]) => [p, v]);
	return interp(swapped[swapped.length - 1][0] >= swapped[0][0] ? swapped : [...swapped].reverse(), px);
}
function topX(cgMm) {
	return interp(TOP_CG, cgMm);
}
function bottomX(cgMm) {
	return interp(BOTTOM_CG, cgMm);
}
function yOfWeight(weightKg) {
	return interp(WEIGHT_Y, weightKg);
}
function weightOfY(y) {
	return invertInterp(WEIGHT_Y, y);
}
/** Pixel position of a (weight, CG) pair on the printed grid. */
function pos(weightKg, cgMm) {
	const y = yOfWeight(weightKg);
	const t = (y - CHART.plotTop) / (CHART.plotBottom - CHART.plotTop);
	return {
		x: topX(cgMm) + t * (bottomX(cgMm) - topX(cgMm)),
		y
	};
}
function cgLine(cgMm) {
	return {
		top: {
			x: topX(cgMm),
			y: CHART.plotTop
		},
		bottom: {
			x: bottomX(cgMm),
			y: CHART.plotBottom
		}
	};
}
/** Recover weight/CG from a click on the graph (binary search on CG). */
function reverse(x, y) {
	const weightKg = weightOfY(y);
	let lo = CHART.cgMin;
	let hi = CHART.cgMax;
	for (let i = 0; i < 60; i++) {
		const mid = (lo + hi) / 2;
		if (pos(weightKg, mid).x < x) lo = mid;
		else hi = mid;
	}
	return {
		weightKg,
		cgMm: (lo + hi) / 2
	};
}
function inPlotBox(x, y) {
	return x >= CHART.plotLeft && x <= CHART.plotRight && y >= CHART.plotTop && y <= CHART.plotBottom;
}
function inChartRange(weightKg, cgMm) {
	const p = pos(weightKg, cgMm);
	return weightKg >= CHART.weightMin && weightKg <= CHART.weightMax && inPlotBox(p.x, p.y);
}
/**
* Printed "NO BALLAST" corridor — dashed boundaries calibrated to the
* supplied page-9 image.
*/
function noBallastLeftX(y) {
	const t = Math.max(0, Math.min(1, (y - 350) / 350));
	return 813 + 99 * t + 10 * t * (1 - t);
}
function noBallastRightX(y) {
	const t = Math.max(0, Math.min(1, (y - 350) / 350));
	return 850 + 220 * t + 7 * t * (1 - t);
}
function isNoBallast(x, y) {
	return x >= noBallastLeftX(y) && x <= noBallastRightX(y);
}
function pointZone(p) {
	return isNoBallast(p.x, p.y) ? "NO BALLAST" : "BALLAST";
}
function neighbouringMarks(cgMm) {
	const marks = [.../* @__PURE__ */ new Set([...TOP_CG.map(([v]) => v), ...BOTTOM_CG.map(([v]) => v)])].sort((a, b) => a - b);
	if (marks.some((m) => Math.abs(m - cgMm) < 1e-6)) return null;
	if (cgMm <= marks[0] || cgMm >= marks[marks.length - 1]) return null;
	for (let i = 0; i < marks.length - 1; i++) if (cgMm > marks[i] && cgMm < marks[i + 1]) return {
		left: marks[i],
		right: marks[i + 1]
	};
	return null;
}
var usePlotStore = create()((set) => ({
	points: [],
	nextId: 1,
	connect: true,
	crosshair: true,
	showCgLine: true,
	readMode: false,
	zoom: 1,
	printRequest: 0,
	addPoint: (p) => set((s) => ({
		points: [...s.points, {
			...p,
			id: s.nextId
		}],
		nextId: s.nextId + 1
	})),
	removePoint: (id) => set((s) => ({ points: s.points.filter((pt) => pt.id !== id) })),
	clearLast: () => set((s) => ({ points: s.points.slice(0, -1) })),
	clearAll: () => set({ points: [] }),
	setConnect: (connect) => set({ connect }),
	setCrosshair: (crosshair) => set({ crosshair }),
	setShowCgLine: (showCgLine) => set({ showCgLine }),
	setReadMode: (readMode) => set({ readMode }),
	setZoom: (zoom) => set({ zoom: Math.max(.75, Math.min(2.5, zoom)) }),
	requestPrint: () => set((s) => ({ printRequest: s.printRequest + 1 }))
}));
function exportCsv() {
	const points = usePlotStore.getState().points;
	const rows = [[
		"Point",
		"Weight entered",
		"Weight unit",
		"Weight kg",
		"Weight lb",
		"CG entered",
		"CG unit",
		"CG mm",
		"CG inch"
	]];
	for (const p of points) rows.push([
		String(p.id),
		String(p.rawWeight),
		p.weightUnit,
		String(p.weightKg),
		String(kgToLb(p.weightKg)),
		String(p.rawCg),
		p.cgUnit,
		String(p.cgMm),
		String(mmToIn(p.cgMm))
	]);
	const csv = rows.map((r) => r.map((v) => `"${String(v).replaceAll("\"", "\"\"")}"`).join(",")).join("\n");
	const a = document.createElement("a");
	a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
	a.download = "AS350_B3E_Page9_Points.csv";
	a.click();
}
function ControlPanel() {
	const addPoint = usePlotStore((s) => s.addPoint);
	const clearLast = usePlotStore((s) => s.clearLast);
	const clearAll = usePlotStore((s) => s.clearAll);
	const requestPrint = usePlotStore((s) => s.requestPrint);
	const points = usePlotStore((s) => s.points);
	const connect = usePlotStore((s) => s.connect);
	const crosshair = usePlotStore((s) => s.crosshair);
	const showCgLine = usePlotStore((s) => s.showCgLine);
	const readMode = usePlotStore((s) => s.readMode);
	const setConnect = usePlotStore((s) => s.setConnect);
	const setCrosshair = usePlotStore((s) => s.setCrosshair);
	const setShowCgLine = usePlotStore((s) => s.setShowCgLine);
	const setReadMode = usePlotStore((s) => s.setReadMode);
	const [weight, setWeight] = (0, import_react.useState)("1200");
	const [weightUnit, setWeightUnit] = (0, import_react.useState)("kg");
	const [cg, setCg] = (0, import_react.useState)("3550");
	const [cgUnit, setCgUnit] = (0, import_react.useState)("mm");
	const [error, setError] = (0, import_react.useState)(null);
	function onSubmit(e) {
		e.preventDefault();
		const w0 = parseFloat(weight);
		const c0 = parseFloat(cg);
		if (!Number.isFinite(w0) || !Number.isFinite(c0)) {
			setError("Enter valid weight and CG values.");
			return;
		}
		const weightKg = weightUnit === "lb" ? lbToKg(w0) : w0;
		const cgMm = cgUnit === "in" ? inToMm(c0) : c0;
		if (!inChartRange(weightKg, cgMm)) {
			setError("That position is outside the plotted page-9 chart range.");
			return;
		}
		setError(null);
		addPoint({
			rawWeight: w0,
			weightUnit,
			rawCg: c0,
			cgUnit,
			weightKg,
			cgMm
		});
	}
	const last = points[points.length - 1];
	const lastPt = last ? pos(last.weightKg, last.cgMm) : null;
	const zone = lastPt ? pointZone(lastPt) : null;
	const neighbours = last ? neighbouringMarks(last.cgMm) : null;
	const status = (0, import_react.useMemo)(() => {
		if (!last || !zone) return {
			label: "No point plotted",
			tone: "neutral"
		};
		if (zone === "BALLAST") return {
			label: "Ballast zone",
			tone: "good"
		};
		return {
			label: "No-ballast zone",
			tone: "warn"
		};
	}, [last, zone]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "flex flex-col gap-5 rounded-xl border border-border bg-surface p-5 lg:sticky lg:top-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium uppercase tracking-[0.14em] text-ink",
				children: "Plot a point"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-lg font-semibold tracking-tight text-fg",
				children: "Weight & CG"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "flex flex-col gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "weight",
							children: "Weight"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[1fr_4.75rem] gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "weight",
								inputMode: "decimal",
								value: weight,
								onChange: (e) => setWeight(e.target.value),
								placeholder: "e.g. 1200"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								"aria-label": "Weight unit",
								value: weightUnit,
								onChange: (e) => setWeightUnit(e.target.value),
								className: "h-11 rounded-md border border-border bg-surface px-2 text-sm text-fg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "kg",
									children: "kg"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "lb",
									children: "lb"
								})]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "cg",
							children: "CG / Balance"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[1fr_4.75rem] gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								id: "cg",
								inputMode: "decimal",
								value: cg,
								onChange: (e) => setCg(e.target.value),
								placeholder: "e.g. 3550"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								"aria-label": "CG unit",
								value: cgUnit,
								onChange: (e) => setCgUnit(e.target.value),
								className: "h-11 rounded-md border border-border bg-surface px-2 text-sm text-fg",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "mm",
									children: "mm"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "in",
									children: "inch"
								})]
							})]
						})]
					}),
					error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-bad",
						children: error
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								variant: "primary",
								className: "col-span-2",
								children: "Plot point"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: clearLast,
								children: "Clear last"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								variant: "danger",
								onClick: clearAll,
								children: "Clear all"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: requestPrint,
								children: "Print graph"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								onClick: exportCsv,
								children: "Export CSV"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-2.5 border-t border-border pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
						id: "connect",
						checked: connect,
						onChange: setConnect,
						label: "Connect plotted points"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
						id: "crosshair",
						checked: crosshair,
						onChange: setCrosshair,
						label: "Show crosshair"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
						id: "cgline",
						checked: showCgLine,
						onChange: setShowCgLine,
						label: "Show CG line (bottom to top)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CheckRow, {
						id: "read",
						checked: readMode,
						onChange: setReadMode,
						label: "Click graph to read position"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-lg border border-border bg-surface-2 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.1em] text-muted",
						children: "Current point"
					}),
					last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-3 grid grid-cols-2 gap-x-3 gap-y-2 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Weight"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-right font-mono tabular-nums",
								children: [
									last.rawWeight,
									" ",
									last.weightUnit
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Weight kg"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-right font-mono tabular-nums",
								children: [last.weightKg.toFixed(2), " kg"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "CG"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-right font-mono tabular-nums",
								children: [
									last.rawCg,
									" ",
									last.cgUnit
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "CG inch"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
								className: "text-right font-mono tabular-nums",
								children: [mmToIn(last.cgMm).toFixed(3), " in"]
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "No point plotted"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: status.tone,
							children: status.label
						})
					}),
					neighbours && last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs leading-relaxed text-muted",
						children: [
							"Line sits between the printed ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: neighbours.left
							}),
							" and",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: neighbours.right
							}),
							" millimetre marks, at",
							" ",
							((last.cgMm - neighbours.left) / (neighbours.right - neighbours.left) * 100).toFixed(1),
							"% of that span."
						]
					}) : last ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs leading-relaxed text-muted",
						children: [
							"Line locked to the printed ",
							last.cgMm,
							" mm mark from the bottom scale to the top scale."
						]
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs leading-relaxed text-subtle",
				children: "Reference: the graph is the actual Figure 1/3 from page 9 of the supplied AMM. Plotted lines follow the printed millimetre marks — they are not a single-slope approximation."
			})
		]
	});
}
function CheckRow({ id, checked, onChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		htmlFor: id,
		className: "flex cursor-pointer items-center gap-2.5 text-sm text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			id,
			type: "checkbox",
			checked,
			onChange: (e) => onChange(e.target.checked),
			className: "size-4 accent-fg",
			suppressHydrationWarning: true
		}), label]
	});
}
var OVERLAY = {
	plot: "#c44536",
	plotInk: "#7a2a22",
	halo: "#ffffff",
	connect: "#222222",
	cross: "#444444",
	read: "#1a6aa3",
	ink: "#111111"
};
function haloStroke(ctx, draw, color, width, haloWidth = width + 3.2) {
	ctx.save();
	ctx.lineCap = "round";
	ctx.lineJoin = "round";
	ctx.strokeStyle = OVERLAY.halo;
	ctx.lineWidth = haloWidth;
	ctx.globalAlpha = .92;
	draw();
	ctx.strokeStyle = color;
	ctx.lineWidth = width;
	ctx.globalAlpha = 1;
	draw();
	ctx.restore();
}
function drawCgConstruction(ctx, cgMm, pt) {
	const line = cgLine(cgMm);
	const neighbours = neighbouringMarks(cgMm);
	haloStroke(ctx, () => {
		ctx.beginPath();
		ctx.moveTo(line.bottom.x, line.bottom.y);
		ctx.lineTo(line.top.x, line.top.y);
		ctx.stroke();
	}, OVERLAY.plot, 2.6, 6);
	haloStroke(ctx, () => {
		ctx.beginPath();
		ctx.moveTo(CHART.plotLeft, pt.y);
		ctx.lineTo(pt.x, pt.y);
		ctx.stroke();
	}, OVERLAY.plot, 1.8, 4.4);
	ctx.save();
	ctx.fillStyle = OVERLAY.plot;
	ctx.strokeStyle = OVERLAY.halo;
	ctx.lineWidth = 2;
	for (const p of [line.top, line.bottom]) {
		ctx.beginPath();
		ctx.arc(p.x, p.y, 3.2, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
	}
	ctx.font = "bold 12px IBM Plex Mono, ui-monospace, monospace";
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	const label = `${cgMm.toFixed(cgMm % 1 === 0 ? 0 : 1)}`;
	ctx.lineWidth = 4;
	ctx.strokeStyle = OVERLAY.halo;
	ctx.fillStyle = OVERLAY.plot;
	ctx.strokeText(label, line.top.x, CHART.plotTop - 12);
	ctx.fillText(label, line.top.x, CHART.plotTop - 12);
	ctx.strokeText(label, line.bottom.x, CHART.plotBottom + 14);
	ctx.fillText(label, line.bottom.x, CHART.plotBottom + 14);
	if (neighbours && cgMm !== neighbours.left && cgMm !== neighbours.right) {
		const span = neighbours.right - neighbours.left;
		const frac = (cgMm - neighbours.left) / span;
		ctx.textAlign = "left";
		ctx.textBaseline = "alphabetic";
		ctx.font = "10px IBM Plex Sans, Arial, sans-serif";
		ctx.fillStyle = OVERLAY.plotInk;
		ctx.strokeText(`${(frac * 100).toFixed(0)}% of ${neighbours.left}–${neighbours.right}`, pt.x + 12, pt.y + 36);
		ctx.fillText(`${(frac * 100).toFixed(0)}% of ${neighbours.left}–${neighbours.right}`, pt.x + 12, pt.y + 36);
	}
	ctx.restore();
}
function drawPointMarker(ctx, p, px, py) {
	ctx.save();
	ctx.lineCap = "round";
	ctx.fillStyle = OVERLAY.halo;
	ctx.strokeStyle = OVERLAY.ink;
	ctx.lineWidth = 2;
	ctx.beginPath();
	ctx.arc(px, py, 6, 0, Math.PI * 2);
	ctx.fill();
	ctx.stroke();
	ctx.fillStyle = OVERLAY.plot;
	ctx.beginPath();
	ctx.arc(px, py, 2.4, 0, Math.PI * 2);
	ctx.fill();
	ctx.font = "bold 13px IBM Plex Sans, Arial, sans-serif";
	ctx.textAlign = "left";
	ctx.textBaseline = "alphabetic";
	ctx.lineWidth = 4;
	ctx.strokeStyle = OVERLAY.halo;
	ctx.fillStyle = OVERLAY.ink;
	[
		`P${p.id}`,
		`${kgToLb(p.weightKg).toFixed(1)} lb / ${p.weightKg.toFixed(1)} kg`,
		`${p.cgMm.toFixed(1)} mm / ${mmToIn(p.cgMm).toFixed(3)} in`
	].forEach((text, i) => {
		const x = px + 12;
		const y = py - 12 + i * 15;
		ctx.font = i === 0 ? "bold 13px IBM Plex Sans, Arial, sans-serif" : "11px IBM Plex Sans, Arial, sans-serif";
		ctx.strokeText(text, x, y);
		ctx.fillText(text, x, y);
	});
	ctx.restore();
}
function drawOverlays(ctx, state) {
	const { points, connect, crosshair, showCgLine, readout } = state;
	if (connect && points.length > 1) {
		ctx.save();
		ctx.setLineDash([10, 6]);
		haloStroke(ctx, () => {
			ctx.beginPath();
			const first = pos(points[0].weightKg, points[0].cgMm);
			ctx.moveTo(first.x, first.y);
			for (let i = 1; i < points.length; i++) {
				const p = pos(points[i].weightKg, points[i].cgMm);
				ctx.lineTo(p.x, p.y);
			}
			ctx.stroke();
		}, OVERLAY.connect, 2.8, 6.2);
		ctx.restore();
	}
	if (showCgLine) for (const p of points) drawCgConstruction(ctx, p.cgMm, pos(p.weightKg, p.cgMm));
	for (const p of points) {
		const pt = pos(p.weightKg, p.cgMm);
		if (crosshair) {
			ctx.save();
			ctx.setLineDash([7, 6]);
			haloStroke(ctx, () => {
				ctx.beginPath();
				ctx.moveTo(pt.x, CHART.plotTop);
				ctx.lineTo(pt.x, pt.y);
				ctx.moveTo(CHART.plotLeft, pt.y);
				ctx.lineTo(pt.x, pt.y);
				ctx.stroke();
			}, OVERLAY.cross, 1.6, 4);
			ctx.restore();
		}
		drawPointMarker(ctx, p, pt.x, pt.y);
	}
	if (readout) {
		const line = cgLine(readout.cgMm);
		ctx.save();
		ctx.setLineDash([4, 4]);
		haloStroke(ctx, () => {
			ctx.beginPath();
			ctx.moveTo(line.bottom.x, line.bottom.y);
			ctx.lineTo(line.top.x, line.top.y);
			ctx.stroke();
		}, OVERLAY.read, 1.6, 4);
		ctx.fillStyle = OVERLAY.read;
		ctx.strokeStyle = OVERLAY.halo;
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.arc(readout.x, readout.y, 4, 0, Math.PI * 2);
		ctx.fill();
		ctx.stroke();
		ctx.restore();
	}
}
async function rasterizeChart(image, state, pixelRatio = 2) {
	const canvas = document.createElement("canvas");
	canvas.width = Math.round(CHART.imageWidth * pixelRatio);
	canvas.height = Math.round(CHART.imageHeight * pixelRatio);
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not create print canvas.");
	ctx.fillStyle = "#ffffff";
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
	ctx.scale(pixelRatio, pixelRatio);
	drawOverlays(ctx, state);
	return canvas.toDataURL("image/png");
}
var IMAGE_SRC = "/as350-figure-1-3.png";
function PlotCanvas() {
	const svgRef = (0, import_react.useRef)(null);
	const imgRef = (0, import_react.useRef)(null);
	const wrapRef = (0, import_react.useRef)(null);
	const points = usePlotStore((s) => s.points);
	const connect = usePlotStore((s) => s.connect);
	const crosshair = usePlotStore((s) => s.crosshair);
	const showCgLine = usePlotStore((s) => s.showCgLine);
	const readMode = usePlotStore((s) => s.readMode);
	const zoom = usePlotStore((s) => s.zoom);
	const printRequest = usePlotStore((s) => s.printRequest);
	const requestPrint = usePlotStore((s) => s.requestPrint);
	const [readout, setReadout] = (0, import_react.useState)(null);
	const [tip, setTip] = (0, import_react.useState)(null);
	const [fit, setFit] = (0, import_react.useState)(1);
	const [printUrl, setPrintUrl] = (0, import_react.useState)(null);
	const printSeq = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		const el = wrapRef.current;
		if (!el) return;
		const update = () => {
			const w = Math.max(320, el.clientWidth - 2);
			setFit(w / CHART.imageWidth);
		};
		update();
		const ro = new ResizeObserver(update);
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	(0, import_react.useEffect)(() => {
		if (printRequest === 0) return;
		let cancelled = false;
		const seq = ++printSeq.current;
		async function run() {
			const img = imgRef.current;
			if (!img) return;
			if (!img.complete) await new Promise((resolve, reject) => {
				img.addEventListener("load", () => resolve(), { once: true });
				img.addEventListener("error", () => reject(/* @__PURE__ */ new Error("Chart image failed to load")), { once: true });
			});
			const state = usePlotStore.getState();
			try {
				const url = await rasterizeChart(img, {
					points: state.points,
					connect: state.connect,
					crosshair: state.crosshair,
					showCgLine: state.showCgLine,
					readout
				});
				if (cancelled || seq !== printSeq.current) return;
				document.body.classList.add("is-printing");
				setPrintUrl(url);
			} catch {
				if (cancelled || seq !== printSeq.current) return;
				window.print();
			}
		}
		run();
		return () => {
			cancelled = true;
		};
	}, [printRequest, readout]);
	(0, import_react.useEffect)(() => {
		const after = () => {
			document.body.classList.remove("is-printing");
			setPrintUrl(null);
		};
		const onKey = (e) => {
			if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "p") {
				e.preventDefault();
				requestPrint();
			}
		};
		window.addEventListener("afterprint", after);
		window.addEventListener("keydown", onKey);
		return () => {
			window.removeEventListener("afterprint", after);
			window.removeEventListener("keydown", onKey);
		};
	}, [requestPrint]);
	const scale = fit * zoom;
	function graphCoords(e) {
		const svg = svgRef.current;
		if (!svg) return null;
		const r = svg.getBoundingClientRect();
		if (r.width === 0 || r.height === 0) return null;
		return {
			x: (e.clientX - r.left) / r.width * CHART.imageWidth,
			y: (e.clientY - r.top) / r.height * CHART.imageHeight
		};
	}
	function onClick(e) {
		if (!readMode) return;
		const c = graphCoords(e);
		if (!c || !inPlotBox(c.x, c.y)) return;
		const q = reverse(c.x, c.y);
		setReadout({
			...q,
			x: c.x,
			y: c.y
		});
	}
	function onMove(e) {
		const c = graphCoords(e);
		if (!c || !inPlotBox(c.x, c.y)) {
			setTip(null);
			return;
		}
		const q = reverse(c.x, c.y);
		setTip({
			x: e.clientX,
			y: e.clientY,
			text: `${q.weightKg.toFixed(1)} kg · ${q.cgMm.toFixed(1)} mm`
		});
	}
	const last = points[points.length - 1];
	const lastZone = last ? pointZone(pos(last.weightKg, last.cgMm)) : null;
	const textScale = 1 / Math.max(scale, .001);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex gap-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomButtons, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Overlay only — the printed Figure 1/3 is unchanged. CG lines lock to the top and bottom millimetre marks."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				ref: wrapRef,
				className: "chart-wrap max-h-[min(78vh,920px)] overflow-auto rounded-lg border border-border bg-white",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "chart-stage relative origin-top-left",
					style: {
						width: CHART.imageWidth * scale,
						height: CHART.imageHeight * scale
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						ref: imgRef,
						src: IMAGE_SRC,
						alt: "AS350 B3e AMM page 9 Figure 1/3 weight and balance graph",
						width: CHART.imageWidth,
						height: CHART.imageHeight,
						crossOrigin: "anonymous",
						className: "block select-none",
						style: {
							width: CHART.imageWidth * scale,
							height: CHART.imageHeight * scale
						},
						draggable: false
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
						ref: svgRef,
						viewBox: `0 0 ${CHART.imageWidth} ${CHART.imageHeight}`,
						width: CHART.imageWidth,
						height: CHART.imageHeight,
						onClick,
						onMouseMove: onMove,
						onMouseLeave: () => setTip(null),
						className: cn("chart-overlay absolute inset-0 size-full", readMode ? "cursor-crosshair" : "cursor-default"),
						"aria-label": "Plotted weight and balance overlay",
						children: [
							connect && points.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloPolyline, {
								points: points.map((p) => {
									const q = pos(p.weightKg, p.cgMm);
									return `${q.x},${q.y}`;
								}).join(" "),
								color: OVERLAY.connect,
								width: 2.8,
								dash: "10 6"
							}) : null,
							showCgLine ? points.map((p) => {
								const pt = pos(p.weightKg, p.cgMm);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CgConstruction, {
									cgMm: p.cgMm,
									pt,
									textScale
								}, `cg-${p.id}`);
							}) : null,
							points.map((p) => {
								const pt = pos(p.weightKg, p.cgMm);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [crosshair ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloLine, {
									x1: pt.x,
									y1: CHART.plotTop,
									x2: pt.x,
									y2: pt.y,
									color: OVERLAY.cross,
									width: 1.6,
									dash: "7 6"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloLine, {
									x1: CHART.plotLeft,
									y1: pt.y,
									x2: pt.x,
									y2: pt.y,
									color: OVERLAY.cross,
									width: 1.6,
									dash: "7 6"
								})] }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PointMarker, {
									p,
									x: pt.x,
									y: pt.y,
									textScale
								})] }, `pt-${p.id}`);
							}),
							readout ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [(() => {
								const line = cgLine(readout.cgMm);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloLine, {
									x1: line.bottom.x,
									y1: line.bottom.y,
									x2: line.top.x,
									y2: line.top.y,
									color: OVERLAY.read,
									width: 1.6,
									dash: "4 4"
								});
							})(), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: readout.x,
								cy: readout.y,
								r: 4,
								fill: OVERLAY.read,
								stroke: OVERLAY.halo,
								strokeWidth: 2,
								vectorEffect: "non-scaling-stroke"
							})] }) : null
						]
					})]
				})
			}),
			readout ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print rounded-md border border-border bg-surface-2 px-3 py-2 text-sm text-fg",
				children: [
					"Graph readout:",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-mono tabular-nums",
						children: [
							readout.weightKg.toFixed(2),
							" kg (",
							kgToLb(readout.weightKg).toFixed(1),
							" lb) ·",
							" ",
							readout.cgMm.toFixed(1),
							" mm (",
							mmToIn(readout.cgMm).toFixed(3),
							" in)"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-2 text-muted",
						children: "Approximate graph reading."
					})
				]
			}) : null,
			lastZone ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "sr-only",
				children: [
					"Last point is in the ",
					lastZone,
					" zone."
				]
			}) : null,
			tip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none fixed z-30 rounded-md bg-fg px-2.5 py-1.5 font-mono text-xs text-bg shadow-lg",
				style: {
					left: tip.x + 12,
					top: tip.y + 12
				},
				children: tip.text
			}) : null,
			printUrl ? (0, import_react_dom.createPortal)(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PrintSheet, { url: printUrl }), document.body) : null
		]
	});
}
function PrintSheet({ url }) {
	const imgRef = (0, import_react.useRef)(null);
	const printed = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		printed.current = false;
		const img = imgRef.current;
		if (!img) return;
		const go = () => {
			if (printed.current) return;
			printed.current = true;
			window.print();
		};
		if (img.complete && img.naturalWidth > 0) {
			const id = window.requestAnimationFrame(go);
			return () => window.cancelAnimationFrame(id);
		}
		img.addEventListener("load", go);
		return () => img.removeEventListener("load", go);
	}, [url]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "print-sheet",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			ref: imgRef,
			src: url,
			alt: "AS350 B3e Figure 1/3 with plotted points"
		})
	});
}
function HaloLine({ x1, y1, x2, y2, color, width, dash }) {
	const common = {
		x1,
		y1,
		x2,
		y2,
		fill: "none",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		vectorEffect: "non-scaling-stroke",
		strokeDasharray: dash
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
		...common,
		stroke: OVERLAY.halo,
		strokeWidth: width + 3.4
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
		...common,
		stroke: color,
		strokeWidth: width
	})] });
}
function HaloPolyline({ points, color, width, dash }) {
	const common = {
		points,
		fill: "none",
		strokeLinecap: "round",
		strokeLinejoin: "round",
		vectorEffect: "non-scaling-stroke",
		strokeDasharray: dash
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
		...common,
		stroke: OVERLAY.halo,
		strokeWidth: width + 3.4
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
		...common,
		stroke: color,
		strokeWidth: width
	})] });
}
function HaloText({ x, y, children, fill = OVERLAY.ink, size = 12, anchor = "start", weight = "normal", font = "sans" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("text", {
		x,
		y,
		fill,
		stroke: OVERLAY.halo,
		strokeWidth: 3.6,
		paintOrder: "stroke",
		fontSize: size,
		fontWeight: weight,
		textAnchor: anchor,
		dominantBaseline: "middle",
		fontFamily: font === "mono" ? "IBM Plex Mono, ui-monospace, monospace" : "IBM Plex Sans, Arial, sans-serif",
		children
	});
}
function CgConstruction({ cgMm, pt, textScale }) {
	const line = cgLine(cgMm);
	const neighbours = neighbouringMarks(cgMm);
	const label = `${cgMm.toFixed(cgMm % 1 === 0 ? 0 : 1)}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloLine, {
			x1: line.bottom.x,
			y1: line.bottom.y,
			x2: line.top.x,
			y2: line.top.y,
			color: OVERLAY.plot,
			width: 2.8
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloLine, {
			x1: CHART.plotLeft,
			y1: pt.y,
			x2: pt.x,
			y2: pt.y,
			color: OVERLAY.plot,
			width: 1.8
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: line.top.x,
			cy: line.top.y,
			r: 3.2,
			fill: OVERLAY.plot,
			stroke: OVERLAY.halo,
			strokeWidth: 2,
			vectorEffect: "non-scaling-stroke"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
			cx: line.bottom.x,
			cy: line.bottom.y,
			r: 3.2,
			fill: OVERLAY.plot,
			stroke: OVERLAY.halo,
			strokeWidth: 2,
			vectorEffect: "non-scaling-stroke"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			transform: `translate(${line.top.x} ${CHART.plotTop - 12}) scale(${textScale})`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloText, {
				x: 0,
				y: 0,
				fill: OVERLAY.plot,
				size: 12,
				anchor: "middle",
				weight: "bold",
				font: "mono",
				children: label
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			transform: `translate(${line.bottom.x} ${CHART.plotBottom + 14}) scale(${textScale})`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloText, {
				x: 0,
				y: 0,
				fill: OVERLAY.plot,
				size: 12,
				anchor: "middle",
				weight: "bold",
				font: "mono",
				children: label
			})
		}),
		neighbours && cgMm !== neighbours.left && cgMm !== neighbours.right ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("g", {
			transform: `translate(${pt.x + 12} ${pt.y + 36}) scale(${textScale})`,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloText, {
				x: 0,
				y: 0,
				fill: OVERLAY.plotInk,
				size: 10,
				children: `${((cgMm - neighbours.left) / (neighbours.right - neighbours.left) * 100).toFixed(0)}% of ${neighbours.left}–${neighbours.right}`
			})
		}) : null
	] });
}
function PointMarker({ p, x, y, textScale }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
		transform: `translate(${x} ${y}) scale(${textScale})`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: 0,
				cy: 0,
				r: 6.2,
				fill: OVERLAY.halo,
				stroke: OVERLAY.ink,
				strokeWidth: 2
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: 0,
				cy: 0,
				r: 2.5,
				fill: OVERLAY.plot
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloText, {
				x: 12,
				y: -14,
				size: 13,
				weight: "bold",
				children: `P${p.id}`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloText, {
				x: 12,
				y: 1,
				size: 11,
				children: `${kgToLb(p.weightKg).toFixed(1)} lb / ${p.weightKg.toFixed(1)} kg`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HaloText, {
				x: 12,
				y: 16,
				size: 11,
				children: `${p.cgMm.toFixed(1)} mm / ${mmToIn(p.cgMm).toFixed(3)} in`
			})
		]
	});
}
function ZoomButtons() {
	const zoom = usePlotStore((s) => s.zoom);
	const setZoom = usePlotStore((s) => s.setZoom);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "h-9 rounded-sm border border-border bg-surface-2 px-3 text-sm text-fg hover:bg-surface",
			onClick: () => setZoom(zoom / 1.25),
			children: "Zoom −"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "h-9 rounded-sm border border-border bg-surface-2 px-3 text-sm text-fg hover:bg-surface",
			onClick: () => setZoom(zoom * 1.25),
			children: "Zoom +"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "h-9 rounded-sm border border-border bg-surface-2 px-3 text-sm text-fg hover:bg-surface",
			onClick: () => setZoom(1),
			children: "Reset"
		})
	] });
}
function PointsTable() {
	const points = usePlotStore((s) => s.points);
	const removePoint = usePlotStore((s) => s.removePoint);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl border border-border bg-surface p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-xs font-medium uppercase tracking-[0.12em] text-muted",
			children: "Plotted points"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[720px] border-collapse text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border text-xs uppercase tracking-[0.08em] text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3 font-medium",
							children: "Point"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3 font-medium",
							children: "Weight"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3 font-medium",
							children: "kg"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3 font-medium",
							children: "lb"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3 font-medium",
							children: "CG mm"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3 font-medium",
							children: "CG inch"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 pr-3 font-medium",
							children: "Zone"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "py-2 font-medium" })
					]
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: points.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					colSpan: 8,
					className: "py-6 text-muted",
					children: "No points plotted."
				}) }) : points.map((p) => {
					const zone = pointZone(pos(p.weightKg, p.cgMm));
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border/70",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2.5 pr-3 font-medium",
								children: ["P", p.id]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "py-2.5 pr-3 font-mono tabular-nums",
								children: [
									p.rawWeight,
									" ",
									p.weightUnit
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 pr-3 font-mono tabular-nums",
								children: p.weightKg.toFixed(3)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 pr-3 font-mono tabular-nums",
								children: kgToLb(p.weightKg).toFixed(3)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 pr-3 font-mono tabular-nums",
								children: p.cgMm.toFixed(3)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 pr-3 font-mono tabular-nums",
								children: mmToIn(p.cgMm).toFixed(4)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 pr-3",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: zone === "BALLAST" ? "text-good" : "text-warn",
									children: zone
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "py-2.5 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "danger",
									size: "sm",
									onClick: () => removePoint(p.id),
									children: "Delete"
								})
							})
						]
					}, p.id);
				}) })]
			})
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "app-screen min-h-dvh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "no-print border-b border-border bg-surface px-5 py-4 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.16em] text-ink",
						children: "Airbus Helicopters · AMM Figure 1/3"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-2xl font-semibold tracking-tight sm:text-3xl",
						children: "AS350 B3e Weight & Balance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-2xl text-sm text-muted",
						children: "Exact page-9 graph. Enter a CG and the overlay follows the printed millimetre line from the bottom scale to the top scale — including values that fall between marks."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "app-main mx-auto max-w-[1500px] px-4 py-5 sm:px-6 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "app-grid grid items-start gap-5 lg:grid-cols-[minmax(16.5rem,20rem)_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "no-print",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ControlPanel, {})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "app-chart-col flex min-w-0 flex-col gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
							className: "chart-panel rounded-xl border border-border bg-surface p-3 sm:p-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlotCanvas, {})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "no-print",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PointsTable, {})
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "no-print px-6 pb-8 text-center text-xs text-subtle",
				children: "For engineering and reference use only. Verify against the current approved aircraft Weight & Balance documentation before operational use."
			})
		]
	});
}
//#endregion
export { Home as component };
