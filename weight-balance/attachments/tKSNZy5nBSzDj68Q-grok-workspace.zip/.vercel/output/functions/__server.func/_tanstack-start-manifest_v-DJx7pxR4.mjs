//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DJx7pxR4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-FHKVBoZw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-FHKVBoZw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-uhxxCodq.js"]
	}
} });
//#endregion
export { tsrStartManifest };
