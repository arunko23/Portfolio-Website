//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DtZn3ui1.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DPT-JaGM.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DPT-JaGM.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BDAM3ct1.js"]
	}
} });
//#endregion
export { tsrStartManifest };
